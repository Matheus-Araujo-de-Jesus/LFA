import java.util.Scanner;
public class main {
	public static void main(String[] args){
		Scanner teclado = new Scanner (System.in);
		int moeda;
		int valor;
		int soma;
		System.out.println("Insira a moeda. (S� S�O ACEITAS MOEDAS DE 0,10 E 0,25).");
		moeda = teclado.nextInt();		
		
		valor = moeda;

		if(valor!=10 && valor!=25){
			System.out.println("Moeda n�o aceita!");
		}
		else {
			do{
				System.out.println("Insira a moeda. (S� S�O ACEITAS MOEDAS DE 0,10 E 0,25).");
				moeda = teclado.nextInt();		
				valor = moeda;
				soma = valor + moeda;
				if(soma == 45) {
					System.out.println("Refrigerante comprado.");
				}
				if (soma > 45) {
					System.out.println("Refrigerante comprado. PS: N�O TRABALHAMOS COM TROCO");
				}
			}while(valor < 45);
		}
	}

}
